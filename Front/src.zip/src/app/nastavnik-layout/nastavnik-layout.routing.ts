import {Routes} from '@angular/router';
import {AdminProfilComponent} from '../admin-profil/admin-profil.component';

export const NastavnikLayoutRutes: Routes = [
  { path: 'magacionerProfil',      component: AdminProfilComponent }
];
