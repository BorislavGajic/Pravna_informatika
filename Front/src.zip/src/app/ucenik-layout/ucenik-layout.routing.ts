import {Routes} from '@angular/router';
import {UcenikProfilComponent} from '../ucenik-profil/ucenik-profil.component';

export const UcenikLayoutRutes: Routes = [
  { path: 'operaterProfil',      component: UcenikProfilComponent },
];
