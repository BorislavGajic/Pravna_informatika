import {Routes} from '@angular/router';
import {AdminProfilComponent} from '../admin-profil/admin-profil.component';

export const AdminLayoutRutes: Routes = [
  { path: 'profilAdmin',      component: AdminProfilComponent }
  // { path: 'kancelarijeAdmin',      component: AdminKancelarijaComponent },

];
